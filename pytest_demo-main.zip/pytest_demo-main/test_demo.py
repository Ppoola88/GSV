import pytest
import csv

from lib import open_page


csv_data = []
with open('testdata.csv', mode='r')as file:
    csvFile = csv.reader(file)

    for lines in csvFile:
        csv_data.append(lines)
        print(lines)


@pytest.mark.parametrize('line', [x for x in csv_data[1:]])
def test_download_pdf(webui, line):
    print(f"Test data: {line}")
    driver = webui
    open_page(driver, line[0])



