from allure import step


@step
def open_page(driver, url):
    driver.get(url)
